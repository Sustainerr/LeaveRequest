﻿namespace TelnetTeamClient.DTO
{
    public class UpdateCongesDispoDto
    {
        public int Matricule { get; set; }
        public int CongesDispo { get; set; }
    }
}
