﻿namespace TelnetTeamClient.DTO
{
    public class UpdateCongeDatesDto
    {
        public DateTime Date_Debut { get; set; }
        public DateTime Date_Fin { get; set; }
    }
}
