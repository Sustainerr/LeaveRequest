﻿namespace TelnetTeamClient.DTO
{
    public class LoginDto
    {
        public int Matricule { get; set; }
        public string MotDePasse { get; set; }
    }
}
