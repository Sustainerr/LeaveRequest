﻿namespace TelnetTeamClient.DTO
{
    public class TypeCongeDto
    {
        public string Type { get; set; }
        public string Role { get; set; }
    }
}
